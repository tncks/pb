#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int mygetpid(void)
{
 return myproc()->pid;
 //return 0xABCDABCD;
}


//Wrapper 
int sys_mygetpid(void)
{

 return mygetpid();
}


int getgpid(void)
{
 return myproc()->parent->parent->pid;
 //return 0xABCDABCD;
}

//Wrapper 
int sys_getgpid(void)
{
 return getgpid();
}
